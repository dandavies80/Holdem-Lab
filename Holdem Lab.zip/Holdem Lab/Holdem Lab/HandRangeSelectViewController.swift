//
//  HandRangeSelectViewController.swift
//  PokerLab
//
//  Created by Daniel Davies on 6/30/20.
//  Copyright © 2020 Daniel Davies. All rights reserved.
//

import Cocoa


class HandRangeSelectViewController: NSViewController {
    
    let pairsStr = "Pairs"
    let allStr = "All"
    
    @IBOutlet weak var playerLabel: NSButton!
    
    @IBAction func holeCardRepButtonPressed(_ sender: NSButton) {
        updateHandRange()
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do view setup here.
        
        print(curPlayer)
        playerLabel.title = "Select Hand Range for Player " + String(curPlayer)
  
        print(playerLabel.title)
    }
    
    func updateHandRange() {
        // update hand range based on hole card rep buttons
        
        // get all selected hole card reps
        holeCardRepsArray = []
        for view in self.view.subviews as [NSView] {
            if let btn = view as? NSButton {
                if allHoleCardReps.contains(btn.title) {
                    // hand range rep button
                    if (btn.state == NSControl.StateValue.on) {
                        holeCardRepsArray.append(btn.title)
                    }
                }
            }
        }
    

    
    /*
        let handRangeStr:String = holeCardRepsArray.joined(separator: ", ")
        let compressedHandRange:[String] = compressHandRanges(handRanges: [holeCardRepsArray])[0]
        let compressedHandRangeStr: String = compressedHandRange.joined(separator: ", ")
        
        textField.stringValue = handRangeStr
        textFieldCompressed.stringValue = compressedHandRangeStr
 */
    }
    

}
