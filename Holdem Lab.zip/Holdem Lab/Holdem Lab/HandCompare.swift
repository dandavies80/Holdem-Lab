//
//  HandCompare.swift
//  PokerLab
//
//  Created by Daniel Davies on 6/25/20.
//  Copyright © 2020 Daniel Davies. All rights reserved.
//

import Cocoa

// min and max ranks and suits
let minRank = 2
let maxRank = 14 // Ace
let minSuit = 0
let maxSuit = 3

// rank and suit dictionaries
let ranksDict:[Character:Int] = ["2":2, "3":3, "4":4, "5":5, "6":6, "7":7, "8":8, "9":9, "T":10, "J":11, "Q":12, "K":13, "A":14]
let suitsDict:[Character:Int] = ["c":0, "d":1, "h":2, "s":3]
let allRanks = ["", "", "2", "3", "4", "5", "6", "7", "8", "9", "T", "J", "Q", "K", "A"]
let allSuits = ["c", "d", "h", "s"]

class Card {
    // card class including integer rank and suit
    // method to convert the card to a readable string like "As"
    
    var rank:Int
    var suit:Int

    init(rank:Int, suit:Int) {
        self.rank = rank
        self.suit = suit
    }
    
    func string() -> String {
        // convert the card to string
        return allRanks[rank] + allSuits[suit]
    }
}



func compareHands(handsArray:[[Card]]) -> [Double] {
    // compare input hands (Card arrays)
    // return an array of Doubles representing the score for each input hand
    // Winning is worth 1, and ties split the win evenly (two winners each get 0.5, three each get 0.33)
    
    // get evaluation for each hand and keep track of max
    var handEvalsArray:[Int] = []
    var maxEval:Int = 0 // maximum score
    var maxEvalCount:Int = 0 // the number of hands with maxScore
    for hand in handsArray {
        let curHandEval = handEval(hand:hand)
        handEvalsArray.append(curHandEval)
        if (curHandEval > maxEval) {
            // new max evaluation
            maxEval = curHandEval
            maxEvalCount = 1
        } else if (curHandEval == maxEval) {
            // tie
            maxEvalCount += 1
        }
    }
    
    // get winner scores
    var scoreOutput:[Double] = []
    for eval in handEvalsArray {
        if (eval == maxEval) {
            // winner
            scoreOutput.append(Double(1)/Double(maxEvalCount))
        } else {
            // loser
            scoreOutput.append(0)
        }
    }
    
    return scoreOutput
    
}

func handEval(hand:[Card]) -> Int {
    // take in an array of Cards and return an 11-digit integer representing the strength of the hand
    // First Number: hand type value (1 for high card, 9 for straight flush)
    // Next Numbers: strength of main cards (pair rank for a pair, high card for a straight, trips rank + pair rank for a full house)
    // Last Numbers: kickers, in order of rank
    // Examples:
    // Kh Tc 9d 8c 5s 4c 3s 11310090805 King high 9854 kicker
    // 3s 3d Ac Kh 9d 8c 2s 20300141309 Pair of 3's AK9 kicker
    // Kc Ks 4c 4s 8c 7h 2s 31304000008 Ks over 4s 8 kicker
    // 3c 3c 3s As Ks Qc 4s 40300001413 Trip 3's AK kicker
    // 7c 8c 9s Ts Js Kh 5d 51100000000 Straight to the J
    // Qs Ts 9s 8s 6s 7c Ad 61210090806 Q-high Flush
    // 5c 5d 5s Td Th 8h As 70510000000 5's full of T's
    // 8c 8d 8h 8s Ac 4d Td 80800000014 Quad 8's A kicker
    // 7s 8s 9s Ts Js Ah 6s 91100000000 Straight Flush to the J
    
    // hand type values
    let highCardVal = 1
    let pairVal = 2
    let twoPairVal = 3
    let tripsVal = 4
    let straightVal = 5
    let flushVal = 6
    let fullHouseVal = 7
    let quadsVal = 8
    let straightFlushVal = 9
    let handTypeMultipler = Int(pow(Double(10),10)) // multiplier for hand type value
    let firstRankMultiplier = Int(pow(Double(10), 8)) // multiplier for the first rank indicating and strength (eg trips rank, or high pair rank of two pair)
    let secondRankMultiplier = Int(pow(Double(10), 6)) // multiplier for the second rank indicating and strength (eg low pair rank of two pair)
    
    var isFlush:Bool = false // is there a flush?
    var flushSuit:Int = 0 // suit of a flush, if there is one
    var straightHighRank = 0 // highest rank of a straight, 0 if no straight
    
    // counts of the number of each rank and suit, and ranks of each suit
    var rankCountsArray = Array(repeating: 0, count: maxRank+1)
    var suitCountsArray = Array(repeating: 0, count: maxSuit+1)
    var rankCountsBySuitArray = Array(repeating: Array(repeating: 0, count: maxRank+1), count: maxSuit+1)
    
    // variables used for determining hand type
    var quadsRank = 0 // rank of quads
    var highestTripsRank = 0 // rank of highest ranking trips
    var highestPairRank = 0 // rank of highest ranking pair
    var secondHighestPairRank = 0 // rank of second-highest ranking pair

    // check for empty hand - value 0
    if (hand.count == 0) {
        return 0
    }
    
    // review each card in the hand
    for card in hand {
        // count rank and suits
        rankCountsArray[card.rank] += 1
        suitCountsArray[card.suit] += 1
        rankCountsBySuitArray[card.suit][card.rank] += 1
        
        // find rank counts of 4, 3, and 2
        switch rankCountsArray[card.rank] {
        case 4:
            quadsRank = card.rank
        case 3:
            if (card.rank >= highestTripsRank) {
                highestTripsRank = card.rank
            }
        case 2:
            if (card.rank > highestPairRank) {
                secondHighestPairRank = highestPairRank
                highestPairRank = card.rank
            } else if (card.rank > secondHighestPairRank) {
                secondHighestPairRank = card.rank
            }
        default:
            break
        }
    }

    // check for straight flush and flush
    for suitIndex in minSuit...maxSuit {
        if (suitCountsArray[suitIndex] >= 5) {
            // flush
            
            isFlush = true
            flushSuit = suitIndex
            
            // check for straight
            straightHighRank = checkStraight(ranksArray: rankCountsBySuitArray[suitIndex])
            
            if (straightHighRank != 0) {
                // straight flush
                return (straightFlushVal * handTypeMultipler) + (straightHighRank * firstRankMultiplier)
            }
            break
        }
    }
     
    // check for quads
    if (quadsRank > 0) {
        // get kicker
        let kickerVal = getKickerVal(rankCountsArray: rankCountsArray, numKickers: 1, avoidRanks: [quadsRank])
         return (quadsVal * handTypeMultipler) + (quadsRank * firstRankMultiplier) + kickerVal
    }
    
    // check for full house
    if (highestTripsRank > 0) {
        for rank in (minRank...maxRank).reversed() {
            if (rankCountsArray[rank] >= 2 && rank != highestTripsRank) {
                return (fullHouseVal * handTypeMultipler) + (highestTripsRank * firstRankMultiplier) + (rank * secondRankMultiplier)
            }
        }
    }
    
    // check for flush
    if isFlush {
        // get flush rank values
        let flushRanksVal = getKickerVal(rankCountsArray: rankCountsBySuitArray[flushSuit], numKickers: 5, avoidRanks: [])
        
        return (flushVal * handTypeMultipler) + flushRanksVal
    }
    
    
    // check for straight
    straightHighRank = checkStraight(ranksArray: rankCountsArray)
    if (straightHighRank != 0) {
        return (straightVal * handTypeMultipler) + (straightHighRank * firstRankMultiplier)
    }

    // check for trips
    if (highestTripsRank > 0) {
        // get kickers
        let kickerVal = getKickerVal(rankCountsArray: rankCountsArray, numKickers: 2, avoidRanks: [highestTripsRank])
         return (tripsVal * handTypeMultipler) + (highestTripsRank * firstRankMultiplier) + kickerVal
    }

    // check for two pair
    if (secondHighestPairRank > 0) {
        // get kicker
        let kickerVal = getKickerVal(rankCountsArray: rankCountsArray, numKickers: 1, avoidRanks: [highestPairRank, secondHighestPairRank])
        
        return (twoPairVal * handTypeMultipler) + (highestPairRank * firstRankMultiplier) + (secondHighestPairRank * Int(pow(Double(10),6))) + kickerVal
    }
    
    // check for pair
    if (highestPairRank > 0) {
        // get kickers
        let kickerVal = getKickerVal(rankCountsArray: rankCountsArray, numKickers: 3, avoidRanks: [highestPairRank])
        return (pairVal * handTypeMultipler) + (highestPairRank * firstRankMultiplier) + kickerVal
    }
    
    // high card
    let kickerVal = getKickerVal(rankCountsArray: rankCountsArray, numKickers: 5, avoidRanks: [])
    
    return (highCardVal * handTypeMultipler) + kickerVal

}

func checkStraight(ranksArray:[Int]) -> Int {
    // determines if the ranks in ranksArray represent a straight
    // returns the highest ranksArray index if it is, returns 0 if not
    
    var runningCount = 0 // a running count of consecutive ranks
    var straightHighRank = 0 // highest rank in the straight
    for index in minRank...maxRank {
        if (ranksArray[index] > 0) {
            runningCount += 1
        } else {
            runningCount = 0
        }
        if (runningCount >= 5) {
            // 5 or more consecutive ranks making a straight
            straightHighRank = index
        } else if (runningCount == 4 && index == 5 && ranksArray[maxRank] > 0) {
            // wheel
            straightHighRank = index
        }
    }
    return straightHighRank
}

func getKickerVal(rankCountsArray:[Int], numKickers:Int, avoidRanks:[Int]) -> Int {
    // takes rank counts and returns the value of the kickers
    // do not count avoidRanks, which do not count as kickers
    
    // place kickers in the end
    // get rid of high card variable - all cards are kickers
    
    var kickers = Array(repeating:0, count: 5) // max four kickers
    var kickerCount = 0
    var kickerVal = 0
    for rank in (minRank...maxRank).reversed() {
        if (rankCountsArray[rank] > 0 && !avoidRanks.contains(rank)) {
            for i in 0..<numKickers {
                if (kickers[i] == 0) {
                    kickers[i] = rank
                    kickerCount += 1
                    break
                } else if (rank > kickers[i]) {
                    for j in ((i+1)..<kickers.count).reversed() {
                        kickers[j] = kickers[j-1]
                    }
                    kickers[i] = rank
                    kickerCount += 1
                    break
                }
                
            }
        }

        if (kickerCount == numKickers) {
            var power:Double = 0
            for kickerRank in kickers.reversed() {
                if (kickerRank > 0) {
                    kickerVal += kickerRank * Int(pow(Double(10),power))
                    power += 2
                }
            }
            break
        }
    }
    return kickerVal
}

func isSame(card1:Card, card2:Card) -> Bool {
    // returns true if the two input cards are the same (same rank and same suit)
    if (card1.rank != card2.rank || card2.suit != card2.suit) {
        return false
    }
    return true
}
    


func allDifferent(cardsArray:[Card]) -> Bool {
    // return true if all input cards are different
    for card in cardsArray {
        // count number of occurances of that card in cardsArray
        var cardCount = 0
        for compareCard in cardsArray {
            if (card.rank == compareCard.rank && card.suit == compareCard.suit) {
                cardCount += 1
            }
        }
        if (cardCount > 1) {
            return false
        }
    }
    return true
}
