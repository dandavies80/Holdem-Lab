//
//  Test.swift
//  PokerLab
//
//  Created by Daniel Davies on 6/25/20.
//  Copyright © 2020 Daniel Davies. All rights reserved.
//

import Cocoa

class Test: NSViewController {
    
    // runEvalTest - test the hand evaluation function handEval()
    // runHandCompareTest - test the hand comparison function compareHands()
    
    // TODO: test the function to create hand ranges from a percentage of hands
    // TODO: test the function to create possibleHoleCards from hand ranges
    
    let straightFlushType = 9
    let quadsType = 8
    let fullHouseType = 7
    let flushType = 6
    let straightType = 5
    let tripsType = 4
    let twoPairType = 3
    let pairType = 2
    let highCardType = 1
    
    func runFiveCardEvalTest() {
        // enumerate all 5-card hands and count the number of each hand type
        
        // Possible combinations for each hand type:
        // Straight Flush: 40
        // Quads: 624
        // Full House: 3744
        // Flush: 5108
        // Straight: 10200
        // Trips: 54912
        // Two Pair: 123552
        // Pair: 1098240
        // High Card: 1302540
        
        /*
        Hand types for reference
        let highCardVal = 1
        let pairVal = 2
        let twoPairVal = 3
        let tripsVal = 4
        let straightVal = 5
        let flushVal = 6
        let fullHouseVal = 7
        let quadsVal = 8
        let straightFlushVal = 9
        */
        
        // build a deck of cards
        var deck:[Card] = []
        for suit in minSuit...maxSuit {
            for rank in minRank...maxRank {
                deck.append(Card(rank:rank, suit:suit))
            }
        }
        
        // iterate through all combinations of 5 cards, evaluate them, and get hand type
        //let handCompareMgr = HandCompare()
        var handTypeCounts = Array(repeating:0, count: 10) // StraightFlushType + 1
        var handCount = 1
        for a in 0..<deck.count-4 {
            for b in a+1..<deck.count-3 {
                for c in b+1..<deck.count-2 {
                    for d in c+1..<deck.count-1 {
                        for e in d+1..<deck.count {
                            let hand = [deck[a], deck[b], deck[c], deck[d], deck[e]]
                            let eval = handEval(hand: hand)
                            let handType = eval/Int(pow(Double(10),10))
                            handTypeCounts[handType] += 1
                            
                            // print every 10,000th hand
                            if (handCount % 10000 == 0) {
                                print(handCount)
                                print(handToString(hand: hand))
                            }
                            handCount += 1
                        }
                    }
                }
            }
        }
        
        print("Finished.")
        print("Hand Count Total: ", handCount-1)
        print("Hand Type Counts: ", handTypeCounts)
        
    }
    
    func runSevenCardEvalTest() {
        // enumerate all 7-card hands and count the number of each hand type
        
        // Possible combinations for each hand type:
        // Straight Flush: 41584
        // Quads: 224848
        // Full House: 3473184
        // Flush: 4047644
        // Straight: 6180020
        // Trips: 6461620
        // Two Pair: 31433400
        // Pair: 58627800
        // High Card: 23294460
        
        /*
        Hand types for reference
        let highCardVal = 1
        let pairVal = 2
        let twoPairVal = 3
        let tripsVal = 4
        let straightVal = 5
        let flushVal = 6
        let fullHouseVal = 7
        let quadsVal = 8
        let straightFlushVal = 9
        */
        
        // build a deck of cards
        var deck:[Card] = []
        for suit in minSuit...maxSuit {
            for rank in minRank...maxRank {
                deck.append(Card(rank:rank, suit:suit))
            }
        }
        
        // iterate through all combinations of 5 cards, evaluate them, and get hand type
        //let handCompareMgr = HandCompare()
        var handTypeCounts = Array(repeating:0, count: 10) // StraightFlushType + 1
        var handCount = 1
        for a in 0..<deck.count-6 {
            for b in a+1..<deck.count-5 {
                for c in b+1..<deck.count-4 {
                    for d in c+1..<deck.count-3 {
                        for e in d+1..<deck.count-2 {
                            for f in e+1..<deck.count-1 {
                                for g in f+1..<deck.count {
                                    let hand = [deck[a], deck[b], deck[c], deck[d], deck[e], deck[f], deck[g]]
                                     let eval = handEval(hand: hand)
                                     let handType = eval/Int(pow(Double(10),10))
                                     handTypeCounts[handType] += 1
                                     
                                     // print every 10,000th hand
                                     if (handCount % 10000 == 0) {
                                         print(handCount)
                                         print(handToString(hand: hand))
                                     }
                                     handCount += 1
                                }
                            }
                        }
                    }
                }
            }
        }
        
        print("Finished.")
        print("Hand Count Total: ", handCount-1)
        print("Hand Type Counts: ", handTypeCounts)
        
    }
    
    func runCompareTest() {
        // randomly build hands and test handCompare function
        for _ in 0...5 {
            var hand:[Card] = []
            //let handType = Int.random(in: highCardType...straightFlushType)
            let handType = 6
            switch  handType {
            case highCardType:
                hand = getRandomHighCardHand()
            case pairType:
                hand = getRandomPairHand()
            case twoPairType:
                hand = getRandomTwoPairHand()
            case tripsType:
                hand = getRandomTripsHand()
            case straightType:
                hand = getRandomStraightHand()
            case flushType:
                hand = getRandomFlushHand()
            case fullHouseType:
                hand = getRandomFullHouseHand()
            case quadsType:
                hand = getRandomQuadsHand()
            case straightFlushType:
                hand = getRandomStraightFlushHand()
            default:
                break
            }
            
            //let handCompareMgr = HandCompare()
            let eval = handEval(hand: hand)
            print(handToString(hand:hand))
            print(eval)
            print("")
        }
    }
    
    func runHandCompareTest() {
        
        var testNo:Int = 0
        let sameHandTypeProb = 50 // pct
        //let sameHandTypeProb = 100
        
        // manually input hands
        var manuallyInputHands:[[Card]] = []
        var manuallyInputScore:[Double] = []
        
        /*
        manuallyInputHands = [handStrToCards(handStr: "5c Kc Th 6s Qs Kh 3h "),
                              handStrToCards(handStr: "Kc Qd 2s 4s Kh 9h 8c ")]
        manuallyInputScore = [1.0, 0]
        */
        
        while true {
            testNo += 1
            var hands:[[Card]] = []
            var score: [Double] = []
            
            if (manuallyInputHands.count != 0) {
                // do manually input hand
                hands = manuallyInputHands
                score = manuallyInputScore
                
                manuallyInputHands = [] // clear manually input hand and score
                manuallyInputScore = []
            
            } else if (Int.random(in: 1...100) < sameHandTypeProb) {
                // compare two random hands of the same type
                let handType = Int.random(in: highCardType...straightFlushType)
                print("Same Hand Types ", handType)
                
                switch handType {
                case highCardType:
                    (hands, score) = getTwoHighCardHands()
                case pairType:
                    (hands, score) = getTwoPairHands()
                case twoPairType:
                    (hands, score) = getTwoTwoPairHands()
                case tripsType:
                    (hands, score) = getTwoTripsHands()
                case straightType:
                    (hands, score) = getTwoStraightHands()
                case flushType:
                    (hands, score) = getTwoFlushHands()
                case fullHouseType:
                    (hands, score) = getTwoFullHouseHands()
                case quadsType:
                    (hands, score) = getTwoQuadsHands()
                case straightFlushType:
                    (hands, score) = getTwoStraightFlushHands()
                default:
                    break
                }
                
            } else {
                // compare two random hands of different types
                
                // get two hand types and score
                var handTypes: [Int] = []
                while true {
                    handTypes = [Int.random(in: highCardType...straightFlushType), Int.random(in: highCardType...straightFlushType)]
                    
                    if (handTypes[0] != handTypes[1]) {
                        if (handTypes[0] > handTypes[1]) {
                            score = [1,0]
                        } else {
                            score = [0,1]
                        }
                        break
                    }
                }
                
                print("Different Hand Types: ", handTypes)
                
                // get the two hands
                for handType in handTypes {
                    switch handType {
                    case highCardType:
                        hands.append(getRandomHighCardHand())
                    case pairType:
                        hands.append(getRandomPairHand())
                    case twoPairType:
                        hands.append(getRandomTwoPairHand())
                    case tripsType:
                        hands.append(getRandomTripsHand())
                    case straightType:
                        hands.append(getRandomStraightHand())
                    case flushType:
                        hands.append(getRandomFlushHand())
                    case fullHouseType:
                        hands.append(getRandomFullHouseHand())
                    case quadsType:
                        hands.append(getRandomQuadsHand())
                    case straightFlushType:
                        hands.append(getRandomStraightFlushHand())
                    default:
                        break
                    }
                }
            }
            
            // get hand scores
            //let handComparator = HandCompare()
            let testScore:[Double] = compareHands(handsArray: hands)
            
            // debug - get all scores for print
            var handEvalsArray:[Int] = []
            for curHand in hands {
                let curHandEval = handEval(hand:curHand)
                handEvalsArray.append(curHandEval)
            }
            // print hands
            print("Test Number: ", testNo)
            print("Hand 1: ", handToString(hand:hands[0]))
            print("Hand 2: ", handToString(hand:hands[1]))
            print("True Score: ", score)
            print("Hand Evals: ", handEvalsArray)
            print("test Score: ", testScore)

            
            // compare test score with ground truth score
            if (testScore == score) {
                print("correct")
            } else {
                print("incorrect!!")
                break
            }
            
            print("")
        }
        
    }
    
    func randomDifferentRanks(numRanks:Int, avoidRanks:[Int]) -> [Int] {
        // return numRanks different random ranks, avoiding ranks in avoidRanks
        var ranks:[Int] = []
        while (ranks.count < numRanks) {
            let newRank = Int.random(in:minRank...maxRank)
            if !(ranks + avoidRanks).contains(newRank) {
                ranks.append(newRank)
            }
        }
        return ranks
    }
    
    func handToString(hand:[Card]) -> String {
        var handString = String()
        for card in hand {
            handString.append(card.string() + " ")
        }
        return handString
    }
    
    func handStrToCards(handStr:String) -> [Card] {
        // takes in a hand as a string of format "ThJhQhKhAh" and returns the corresponding cards
        
        let ranksDict:[Character:Int] = ["2":2, "3":3, "4":4, "5":5, "6":6, "7":7, "8":8, "9":9, "T":10, "J":11, "Q":12, "K":13, "A":14]
        let suitsDict:[Character:Int] = ["c":0, "d":1, "h":2, "s":3]
        
        var hand:[Card] = []
        let charArray = Array(handStr)
        for charIndex in stride(from:0, to:handStr.count, by:3) {
            let rank = ranksDict[charArray[charIndex]]
            let suit = suitsDict[charArray[charIndex + 1]]
            let card = Card(rank:rank!, suit:suit!)
            hand.append(card)
        }
        return hand
    }
    
    func getRandomStraightFlushHand() -> [Card] {
        // get a random straight flush hand
        
        return buildStraightFlushHand(highRank: Int.random(in:5...maxRank))
    }
    
    func getTwoStraightFlushHands() -> ([[Card]], [Double]) {
        // get two straight flush hands
        
        let highRanks = [Int.random(in:5...maxRank), Int.random(in:5...maxRank)]
        
        let hands = [buildStraightFlushHand(highRank: highRanks[0]), buildStraightFlushHand(highRank: highRanks[1])]
        
        var score:[Double] = []
        if (highRanks[0] > highRanks[1]) {
            score = [1,0]
        } else if (highRanks[1] > highRanks[0]) {
            score = [0,1]
        } else {
            score = [0.5, 0.5]
        }
        
        return (hands, score)
        
    }
    
    func buildStraightFlushHand(highRank:Int) -> [Card] {
        var cardsArray:[Card] = []
        
        // build ranks for straight flush
        var straightFlushRanks:[Int] = []
        if (highRank == 5) {
            // wheel
            straightFlushRanks = [14,2,3,4,5]
        } else {
            for rank in (highRank-4)...highRank {
                straightFlushRanks.append(rank)
            }
        }
        
        // get random suit
        let flushSuit:Int = Int.random(in:minSuit...maxSuit)
        
        // get straight flush cards
        for rank in straightFlushRanks {
            cardsArray.append(Card(rank:rank, suit:flushSuit))
        }
        
        // add two random cards
        // make sure they are not highRank + 1 of the same suit
        let additionalRanks = [Int.random(in: minRank...maxRank), Int.random(in: minRank...maxRank), ]
        
        var additionalSuits:[Int] = [0, 0]
        for index in 0..<additionalRanks.count {
            if (straightFlushRanks.contains(additionalRanks[index]) || additionalRanks[index] == highRank + 1) {
                while true {
                    additionalSuits[index] = Int.random(in:minSuit...maxSuit)
                    if (additionalSuits[index] != flushSuit) {
                        break
                    }
                }
            } else {
                // no suit restriction
                additionalSuits[index] = Int.random(in:minSuit...maxSuit)
                
            }
        }
        let additionalCards = [Card(rank:additionalRanks[0], suit:additionalSuits[0]), Card(rank:additionalRanks[1], suit:additionalSuits[1])]
        cardsArray.append(contentsOf: additionalCards)
        return cardsArray.shuffled()
    }
    
    
    func getRandomQuadsHand() -> [Card] {
        
        let quadsRank = Int.random(in: minRank...maxRank)
        let otherRanks = randomDifferentRanks(numRanks: 3, avoidRanks: [quadsRank])
        return buildQuadsHand(quadRank: quadsRank, otherRanksArray: otherRanks)
    }
    
    func getTwoQuadsHands() -> ([[Card]], [Double]) {
        // get two quads hands
        
        let quadsRanks:[Int] = [Int.random(in: minRank...maxRank), Int.random(in: minRank...maxRank)]
        
        let otherRanks = [randomDifferentRanks(numRanks: 3, avoidRanks: [quadsRanks[0]]).sorted{$0 > $1}, randomDifferentRanks(numRanks: 3, avoidRanks: [quadsRanks[0]]).sorted{$0 > $1}]
        
        let hands = [buildQuadsHand(quadRank: quadsRanks[0], otherRanksArray: otherRanks[0]), buildQuadsHand(quadRank: quadsRanks[1], otherRanksArray: otherRanks[1])]
        
        var score:[Double] = []
        if (quadsRanks[0] > quadsRanks[1]) {
            score = [1,0]
        } else if (quadsRanks[1] > quadsRanks[0]) {
            score = [0,1]
        } else {
            score = compareOtherRanks(otherRanks: otherRanks, numRanksToCompare: 1)
        }
        
        return (hands, score)
    }
    
    func buildQuadsHand(quadRank:Int, otherRanksArray:[Int]) -> [Card] {
        // build a quads hand
        
        var cardsArray:[Card] = []
        
        // enumerate the quads cards
        for suit in minSuit...maxSuit {
            cardsArray.append(Card(rank: quadRank, suit: suit))
        }
        
        // add other ranks
        for rank in otherRanksArray {
            cardsArray.append(Card(rank: rank, suit: Int.random(in: minSuit...maxSuit)))
        }
        
        return cardsArray.shuffled()
    }
    
    func getRandomFullHouseHand() -> [Card] {
        // get a random full house hand
        
        // get trips and pair ranks
        let tripRank = Int.random(in: minRank...maxRank)
        let pairRank = randomDifferentRanks(numRanks: 1, avoidRanks: [tripRank])[0]
        
        return buildFullHouseHand(tripsRank: tripRank, pairRank: pairRank)
    }
    
    func getTwoFullHouseHands() -> ([[Card]], [Double]) {
        // get two full house hands
        
        // get trips and pair ranks
        var tripsRanks: [Int] = []
        var pairRanks: [Int] = []
        while true {
            tripsRanks = [Int.random(in:minRank...maxRank), Int.random(in:minRank...maxRank)]
            pairRanks = [Int.random(in:minRank...maxRank), Int.random(in:minRank...maxRank)]
            if ( (tripsRanks[0] != pairRanks[0]) && (tripsRanks[1] != pairRanks[1]) ) {
                break
            }
        }
        
        let hands = [buildFullHouseHand(tripsRank: tripsRanks[0], pairRank: pairRanks[0]), buildFullHouseHand(tripsRank: tripsRanks[1], pairRank: pairRanks[1])]
        
        // get true winner
        var score: [Double] = []
        if (tripsRanks[0] > tripsRanks[1]) {
            score = [1,0]
        } else if (tripsRanks[1] > tripsRanks[0]) {
            score = [0,1]
        } else {
            if (pairRanks[0] > pairRanks[1]) {
                score = [1,0]
            } else if (pairRanks[1] > pairRanks[0]) {
                score = [0,1]
            } else {
                score = [0.5,0.5]
            }
        }
        
        return (hands, score)
    }
    
    func buildFullHouseHand(tripsRank:Int, pairRank:Int) -> [Card] {
        // build full house hand
        
        // get cards that make the trips and pair
        var tripsCardsArray:[Card] = []
        var pairCardsArray:[Card] = []
        // enumerate all cards for tripsRank and pairRank
        for suit in minSuit...maxSuit {
            tripsCardsArray.append(Card(rank:tripsRank, suit:suit))
            pairCardsArray.append(Card(rank:pairRank, suit:suit))
        }
        // remove one from trips and two from pair
        tripsCardsArray.remove(at:Int.random(in:0..<tripsCardsArray.count))
        pairCardsArray.remove(at:Int.random(in:0..<pairCardsArray.count))
        pairCardsArray.remove(at:Int.random(in:0..<pairCardsArray.count))
        
        // add two cards
        var otherRanks:[Int] = []
        if (tripsRank > pairRank) {
            otherRanks = randomDifferentRanks(numRanks: 2, avoidRanks: [tripsRank])
        } else {
            otherRanks = randomDifferentRanks(numRanks: 2, avoidRanks: [tripsRank, pairRank])
        }
        
        let cardsArray = tripsCardsArray + pairCardsArray + [Card(rank: otherRanks[0], suit: Int.random(in: minSuit...maxSuit))] + [Card(rank: otherRanks[1], suit: Int.random(in: minSuit...maxSuit))]
        
        return cardsArray.shuffled()
        
    }
    
    func getRandomFlushHand() -> [Card] {
        // get random flush hand
        var flushRanks:[Int] = []
        
        while true {
            flushRanks = randomDifferentRanks(numRanks: 5, avoidRanks: [])
            if !isStraight(ranksArray:flushRanks) {
                break
            }
        }
        return buildFlushHand(flushRanks: flushRanks)
    }
    
    func getTwoFlushHands() -> ([[Card]], [Double]) {
        // get two flush hands
        
        // get two sets of flush ranks that don't make straights
        var flushRanks1:[Int] = []
        var flushRanks2:[Int] = []
        while true {
            flushRanks1 = randomDifferentRanks(numRanks: 5, avoidRanks: []).sorted{$0 > $1}
            flushRanks2 = randomDifferentRanks(numRanks: 5, avoidRanks: []).sorted{$0 > $1}
            if (!isStraight(ranksArray:flushRanks1) && !isStraight(ranksArray:flushRanks2)) {
                break
            }
        }
        
        let hands = [buildFlushHand(flushRanks: flushRanks1), buildFlushHand(flushRanks: flushRanks2)]
        
        let score = compareOtherRanks(otherRanks: [flushRanks1, flushRanks2], numRanksToCompare: 5)
        
        return (hands, score)
    }
    
    func buildFlushHand(flushRanks:[Int]) -> [Card] {
        // build a flush hand based on flush ranks.  Flush ranks are sorted high to low.
        var cardsArray:[Card] = []
        
        // get random suit
        let flushSuit:Int = Int.random(in: minSuit...maxSuit)
        
        // get flush cards
        for rank in flushRanks {
            cardsArray.append(Card(rank:rank, suit:flushSuit))
        }
        
        // get twp random additional cards
        var additionalRanks:[Int] = []
        var additionalSuits:[Int] = []
        while true {
            additionalRanks = [Int.random(in: minRank...maxRank), Int.random(in: minRank...maxRank)]
            additionalSuits = [Int.random(in: minSuit...maxSuit), Int.random(in: minSuit...maxSuit)]
            
            // define additional flush ranks array to check for restrictions
            var additionalFlushRanks:[Int] = []
            for index in 0..<additionalRanks.count {
                if (additionalSuits[index] == flushSuit) {
                    additionalFlushRanks.append(additionalRanks[index])
                }
            }
            
            // check for restrictions in the new flush rank array
            // restrictions: duplicated rank, rank above lowest rank, or straight flush
            var additionalCardsOK:Bool = true

            // check duplicated rank restriction
            for rank in additionalFlushRanks {
                if flushRanks.contains(rank) {
                    // restriction failed
                    additionalCardsOK = false
                }
            }
            
            // check rank above flush rank restriction
            if (additionalFlushRanks.max() ?? 0 > flushRanks[4]) {
                // restriction failed
                additionalCardsOK = false
            }
            
            // check straight flush restriction
            if isStraight(ranksArray: flushRanks + additionalFlushRanks) {
                // restriction failed
                additionalCardsOK = false
            }
            
            if additionalCardsOK {
                break
            }
        }
        
        let additionalCards = [Card(rank:additionalRanks[0], suit:additionalSuits[0]), Card(rank:additionalRanks[1], suit:additionalSuits[1])]
        
        print("additional cards: ", additionalCards[0].string(), additionalCards[1].string())
        
        cardsArray.append(contentsOf: additionalCards)
        
        return cardsArray.shuffled()
    }
    
    func getRandomStraightHand() -> [Card] {
        // get a random straight hand
        
        return buildStraightHand(highRank: Int.random(in:5...maxRank))
    }
    
    func getTwoStraightHands() -> ([[Card]], [Double]) {
        // get two straight hands
        let highRanks = [Int.random(in:5...maxRank), Int.random(in:5...maxRank)]
        
        let hands = [buildStraightHand(highRank: highRanks[0]), buildStraightHand(highRank: highRanks[1])]
        
        var score:[Double] = []
        if (highRanks[0] > highRanks[1]) {
            score = [1,0]
        } else if (highRanks[1] > highRanks[0]) {
            score = [0,1]
        } else {
            score = [0.5, 0.5]
        }
        
        return (hands, score)
        
    }
    
    func buildStraightHand(highRank:Int) -> [Card] {
        // build a straight hand
        // it's assumed that highRank is 5 or more
        var cardsArray:[Card] = []
        
        // build ranks for straight
        var straightRanks:[Int] = []
        if (highRank == 5) {
            // wheel
            straightRanks = [14,2,3,4,5]
        } else {
            for rank in (highRank-4)...highRank {
                straightRanks.append(rank)
            }
        }
        
        // add two random ranks, but not one more than highRank
        var ranks:[Int] = []
        if (highRank == maxRank) {
            ranks = straightRanks + [Int.random(in: minRank...maxRank)] + [Int.random(in: minRank...maxRank)]
        } else {
            ranks = straightRanks + randomDifferentRanks(numRanks: 1, avoidRanks: [highRank+1]) + randomDifferentRanks(numRanks: 1, avoidRanks: [highRank+1])
        }
        
        // get random suits, do not make a flush
        while true {
            cardsArray = []
            for rank in ranks {
                cardsArray.append(Card(rank:rank, suit:Int.random(in: minSuit...maxSuit)))
            }
            if !isFlush(cardsArray:cardsArray) {
                break
            }
        }
        return cardsArray.shuffled()
    }
    
    
    func getRandomTripsHand() -> [Card] {
        let tripsRank:Int = Int.random(in:minRank...maxRank)
        
        // get other ranks that don't make a straight
        var otherRanks:[Int] = []
        while true {
            otherRanks = randomDifferentRanks(numRanks: 4, avoidRanks:[tripsRank]).sorted{$0 > $1}
            if !isStraight(ranksArray:[tripsRank] + otherRanks) {
                break
            }
        }
        return buildTripsHand(tripsRank: tripsRank, otherRanksArray: otherRanks)
    }
    
    func getTwoTripsHands() -> ([[Card]], [Double]) {
        // get two trips hands
        
        // get trips rank
        let tripsRanks:[Int] = [Int.random(in:minRank...maxRank), Int.random(in:minRank...maxRank)]
        
        // get other ranks that don't make a straight
        var otherRanks:[[Int]] = []
        while true {
            otherRanks = [randomDifferentRanks(numRanks: 4, avoidRanks:[tripsRanks[0]]).sorted{$0 > $1}, randomDifferentRanks(numRanks: 4, avoidRanks:[tripsRanks[1]]).sorted{$0 > $1}]
            if (!isStraight(ranksArray: [tripsRanks[0]] + otherRanks[0]) && !isStraight(ranksArray: [tripsRanks[1]] + otherRanks[1])) {
                break
            }
        }
        
        // build trips hands
        let hands = [buildTripsHand(tripsRank: tripsRanks[0], otherRanksArray: otherRanks[0]), buildTripsHand(tripsRank: tripsRanks[1], otherRanksArray: otherRanks[1])]
        
        // get true winner (score)
        var score:[Double] = []
        if (tripsRanks[0] > tripsRanks[1]) {
            score = [1,0]
        } else if (tripsRanks[1] > tripsRanks[0]) {
            score = [0,1]
        } else {
            score = compareOtherRanks(otherRanks: otherRanks, numRanksToCompare: 2)
        }
        
        return (hands, score)
    }
    
    
    func buildTripsHand(tripsRank:Int, otherRanksArray:[Int]) -> [Card] {
        // it's assumed that other ranks array are all different, and don't make a straight
        
        var cardsArray:[Card] = []
        
        // get cards that make the trips
        var tripsCardsArray:[Card] = []
        // enumerate all cards of tripsRank
        for suit in minSuit...maxSuit {
            tripsCardsArray.append(Card(rank:tripsRank, suit:suit))
        }
        // randomly remove one of them
        tripsCardsArray.remove(at:Int.random(in:0..<tripsCardsArray.count))
        
        // add other ranks
        while true {
            var otherCardsArray:[Card] = []
            for rank in otherRanksArray {
                otherCardsArray.append(Card(rank:rank, suit:Int.random(in:minSuit...maxSuit)))
            }
            
            // make sure 5 of the same suit aren't there
            // make sure 5 of the same suit aren't there
            if !isFlush(cardsArray: (tripsCardsArray + otherCardsArray)) {
                cardsArray = tripsCardsArray + otherCardsArray
                break
            }
        }
        
        return cardsArray.shuffled()
    }
    
    func getRandomTwoPairHand() -> [Card] {
        var highPairRank:Int = 0
        var lowPairRank:Int = 0
        while true {
            highPairRank = Int.random(in:minRank...maxRank)
            lowPairRank = Int.random(in:minRank...maxRank)
            if (highPairRank != lowPairRank) {
                break
            }
        }
        
        // get other ranks that don't make a straight
        var otherRanks:[Int] = []
        while true {
            otherRanks = randomDifferentRanks(numRanks: 3, avoidRanks: [highPairRank] + [lowPairRank]).sorted{$0 > $1}
            if !isStraight(ranksArray: [highPairRank] + [lowPairRank] + otherRanks) {
                break
            }
        }
        
        return buildTwoPairHand(highPairRank: highPairRank, lowPairRank: lowPairRank, otherRanksArray: otherRanks)
        
    }
    
    func getTwoTwoPairHands() -> ([[Card]], [Double]) {
        // get two two-pair hands
        
        // get high pair and low pair ranks and make sure they're different
        var highPairRanks:[Int] = [0,0]
        var lowPairRanks:[Int] = [0,0]
        while true {
            let pairRanks = [ [Int.random(in:minRank...maxRank), Int.random(in:minRank...maxRank)],
                              [Int.random(in:minRank...maxRank), Int.random(in:minRank...maxRank)]
            ]
            if (pairRanks[0][0] != pairRanks[0][1] && pairRanks[1][0] != pairRanks[1][1]) {
                highPairRanks[0] = pairRanks[0].max()!
                lowPairRanks[0] = pairRanks[0].min()!
                highPairRanks[1] = pairRanks[1].max()!
                lowPairRanks[1] = pairRanks[1].min()!
                break
            }
        }
        
        // get other ranks that don't make a straight
        var otherRanks:[[Int]] = []
        while true {
            otherRanks = [randomDifferentRanks(numRanks: 3, avoidRanks:[highPairRanks[0]] + [lowPairRanks[0]]).sorted{$0 > $1}, randomDifferentRanks(numRanks: 3, avoidRanks:[highPairRanks[1]] + [lowPairRanks[1]]).sorted{$0 > $1}]
            if (!isStraight(ranksArray: [highPairRanks[0]] + [lowPairRanks[0]] + otherRanks[0]) && !isStraight(ranksArray: [highPairRanks[1]] + [lowPairRanks[1]] + otherRanks[1])) {
                break
            }
        }
        
        // build two-pair hands
        let hands = [buildTwoPairHand(highPairRank: highPairRanks[0], lowPairRank: lowPairRanks[0], otherRanksArray:otherRanks[0]), buildTwoPairHand(highPairRank: highPairRanks[1], lowPairRank: lowPairRanks[1], otherRanksArray:otherRanks[1])]
        
        // get true winner (score)
        var score:[Double] = []
        if (highPairRanks[0] > highPairRanks[1]) {
            score = [1,0]
        } else if (highPairRanks[1] > highPairRanks[0]) {
            score = [0,1]
        } else {
            if (lowPairRanks[0] > lowPairRanks[1]) {
                score = [1,0]
            } else if (lowPairRanks[1] > lowPairRanks[0]) {
                score = [0,1]
            } else {
                score = compareOtherRanks(otherRanks: otherRanks, numRanksToCompare:1)
            }
        }
        
        return (hands, score)
    }
    
    func buildTwoPairHand(highPairRank:Int, lowPairRank:Int, otherRanksArray:[Int]) -> [Card] {
        // it's assumed that highPairRank, lowPairRank, and otherRanksArray are all different, and don't make a straight
        
        var cardsArray:[Card] = []
        
        // get cards that make the pairs
        var highPairCardsArray:[Card] = []
        var lowPairCardsArray:[Card] = []
        
        // pick suits
        while true {
            let highPairSuits = [Int.random(in:minSuit...maxSuit), Int.random(in:minSuit...maxSuit)]
            let lowPairSuits = [Int.random(in:minSuit...maxSuit), Int.random(in:minSuit...maxSuit)]
            
            if ( (highPairSuits[0] != highPairSuits[1]) && (lowPairSuits[0] != lowPairSuits[1]) ) {
                highPairCardsArray = [Card(rank:highPairRank, suit: highPairSuits[0]), Card(rank:highPairRank, suit: highPairSuits[1])]
                lowPairCardsArray = [Card(rank:lowPairRank, suit: highPairSuits[0]), Card(rank:lowPairRank, suit: highPairSuits[1])]
                break
            }
        }
        
        // add other ranks
        while true {
            var otherCardsArray:[Card] = []
            for rank in otherRanksArray {
                otherCardsArray.append(Card(rank:rank, suit:Int.random(in:minSuit...maxSuit)))
            }
            
            // make sure there's no flush
            if !isFlush(cardsArray: (highPairCardsArray + lowPairCardsArray + otherCardsArray)) {
                cardsArray = highPairCardsArray + lowPairCardsArray + otherCardsArray
                break
            }
        }
        
        return cardsArray.shuffled()
        
    }
    
    func getRandomPairHand() -> [Card] {
        let pairRank:Int = Int.random(in:minRank...maxRank)
        
        // get other ranks that don't make a straight
        var otherRanks:[Int] = []
        while true {
            otherRanks = randomDifferentRanks(numRanks: 5, avoidRanks:[pairRank]).sorted{$0 > $1}
            if !isStraight(ranksArray:[pairRank] + otherRanks) {
                break
            }
        }
        
        return buildPairHand(pairRank:pairRank, otherRanksArray:otherRanks)
    }
    
    func getTwoPairHands() -> ([[Card]], [Double]) {
        // get two pair hands
        
        let pairRanks:[Int] = [Int.random(in:minRank...maxRank), Int.random(in:minRank...maxRank)]
        
        // get other ranks that don't make a straight
        var otherRanks:[[Int]] = []
        while true {
            otherRanks = [randomDifferentRanks(numRanks: 5, avoidRanks:[pairRanks[0]]).sorted{$0 > $1}, randomDifferentRanks(numRanks: 5, avoidRanks:[pairRanks[1]]).sorted{$0 > $1}]
            if (!isStraight(ranksArray: [pairRanks[0]] + otherRanks[0]) && !isStraight(ranksArray: [pairRanks[1]] + otherRanks[1])) {
                break
            }
        }
        
        // build pair hands
        let hands = [buildPairHand(pairRank: pairRanks[0], otherRanksArray:otherRanks[0]), buildPairHand(pairRank: pairRanks[1], otherRanksArray:otherRanks[1])]
        
        // get true winner (score)
        var score:[Double] = []
        if (pairRanks[0] > pairRanks[1]) {
            score = [1,0]
        } else if (pairRanks[1] > pairRanks[0]) {
            score = [0,1]
        } else {
            score = compareOtherRanks(otherRanks: otherRanks, numRanksToCompare: 3)
        }
        return (hands, score)
    }
    
    func buildPairHand(pairRank: Int, otherRanksArray:[Int]) -> [Card] {
        // it's assumed that other ranks array are all different, and don't make a straight
        
        var cardsArray:[Card] = []
        
        // get cards that make the pair
        var pairCardsArray:[Card] = []
        // pick two suits
        while true {
            let suits = [Int.random(in:minSuit...maxSuit), Int.random(in:minSuit...maxSuit)]
            
            if (suits[0] != suits[1]) {
                pairCardsArray = [Card(rank:pairRank, suit:suits[0]), Card(rank:pairRank, suit:suits[1])]
                break
            }
        }
        
        // add other ranks
        while true {
            var otherCardsArray:[Card] = []
            for rank in otherRanksArray {
                otherCardsArray.append(Card(rank:rank, suit:Int.random(in:minSuit...maxSuit)))
            }
            
            // make sure there's no flush
            if !isFlush(cardsArray: (pairCardsArray + otherCardsArray)) {
                cardsArray = pairCardsArray + otherCardsArray
                break
            }
        }
        
        return cardsArray.shuffled()
        
    }
    
    func getRandomHighCardHand() -> [Card] {
        // get a set of ranks that don't make a straight
        while true {
            let ranks = randomDifferentRanks(numRanks: 7, avoidRanks:[])
            if !isStraight(ranksArray: ranks) {
                return buildHighCardHand(ranksArray: ranks)
            }
        }
    }
    
    func getTwoHighCardHands() -> ([[Card]], [Double]) {
        // get two high card hands
        
        // get two sets of ranks that don't make a straight
        var ranks:[[Int]] = []
        var hands:[[Card]] = []
        while true {
            ranks = [randomDifferentRanks(numRanks: 7, avoidRanks:[]).sorted{$0 > $1}, randomDifferentRanks(numRanks: 7, avoidRanks:[]).sorted{$0 > $1}]
            if (!isStraight(ranksArray:ranks[0]) && !isStraight(ranksArray:ranks[1])) {
                hands = [buildHighCardHand(ranksArray: ranks[0]), buildHighCardHand(ranksArray: ranks[1])]
                break
            }
        }
        
        // get true winner (score)
        let score = compareOtherRanks(otherRanks: ranks, numRanksToCompare: 5)
        
        return (hands, score)
    }
    
    func buildHighCardHand(ranksArray:[Int]) -> [Card] {
        // it's assumed that other ranks array are all different, and don't make a straight
        
        var cardsArray:[Card] = []
        
        // add ranks
        while true {
            cardsArray = []
            for rank in ranksArray {
                cardsArray.append(Card(rank:rank, suit:Int.random(in:minSuit...maxSuit)))
            }
            
            // make sure there's no flush
            if !isFlush(cardsArray: cardsArray) {
                break
            }
        }
        
        return cardsArray.shuffled()
    }
    
    func allDifferent(cardsArray:[Card]) -> Bool {
        // return true if all cards are different
        for card in cardsArray {
            // count number of occurances of that card in cardsArray
            var cardCount = 0
            for compareCard in cardsArray {
                if (card.rank == compareCard.rank && card.suit == compareCard.suit) {
                    cardCount += 1
                }
            }
            if (cardCount > 1) {
                return false
            }
        }
        return true
    }
    
    func isFlush(cardsArray:[Card]) -> Bool {
        // return true if the input cards make a flush
        var suitCounts:[Int] = Array(repeating: 0, count: maxSuit - minSuit + 1)
        for card in cardsArray {
            suitCounts[card.suit] += 1
            if (suitCounts[card.suit] >= 5) {
                return true
            }
        }
        return false
    }
    
    func isStraight(ranksArray:[Int]) -> Bool {
        // return true if the input ranks make a straight.  The ranks can be unsorted.
        let straightRanksArray = [[14,2,3,4,5], [2,3,4,5,6], [3,4,5,6,7], [4,5,6,7,8], [5,6,7,8,9], [6,7,8,9,10], [7,8,9,10,11], [8,9,10,11,12], [9,10,11,12,13], [10,11,12,13,14]]
        for straightRanks in straightRanksArray {
            var rankCount = 0
            for rank in ranksArray {
                if straightRanks.contains(rank) {
                    rankCount += 1
                }
                if (rankCount >= 5) {
                    return true
                }
            }
        }
        return false
    }
    
    func compareOtherRanks(otherRanks:[[Int]], numRanksToCompare:Int) -> [Double] {
        // compares two arrays of ordered otherRanks and returns an array of the scores (1 for win, 0 for lose, 0.5 for tie)
        for index in 0...(numRanksToCompare-1) {
            if (otherRanks[0][index] > otherRanks[1][index]) {
                return [1,0]
            } else if (otherRanks[1][index] > otherRanks[0][index]) {
                return [0,1]
            }
        }
        return [0.5, 0.5]
    }
}
