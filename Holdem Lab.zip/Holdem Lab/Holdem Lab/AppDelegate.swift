//
//  AppDelegate.swift
//  Holdem Lab
//
//  Created by Daniel Davies on 7/19/20.
//  Copyright © 2020 Daniel Davies. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {

    func applicationDidFinishLaunching(_ aNotification: Notification) {
        // Insert code here to initialize your application
    }

    func applicationWillTerminate(_ aNotification: Notification) {
        // Insert code here to tear down your application
    }
}
