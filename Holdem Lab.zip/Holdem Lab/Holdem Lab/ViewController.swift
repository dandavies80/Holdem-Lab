//
//  ViewController.swift
//  PokerLab
//
//  Created by Daniel Davies on 6/20/20.
//  Copyright © 2020 Daniel Davies. All rights reserved.
//

import Cocoa

let numPlayers: Int = 6 // total possible number of players
var curPlayer: Int = 1 // the player to set the hand range for


var holeCardRepsArray:[String] = []
var tableCardsArray: [String] = []
var allHoleCardReps:[String] = [] // all hole card reps
var allHoleCardRepGroups:[String] = [] // all hole card rep groups
var allCards:[String] = [] // all cards

// group button strings
let allStr = "All"
let pairsStr = "Pairs"
let separator = ", " // separator for strings of cards/hole card representations

// simulation variables
var runSimulationFlag = false // start or stop simulation
var numHands = 0 // number of hands simulated

class ViewController: NSViewController {

    // a holeCardRep is a string representation of a type of hole card, like "TT" or "A7s" or "K8o+"
    // a handRange is an array of holeCardReps
    // a playerHandRanges is an array of handRanges, containing hand ranges for each player
    // possibleHoleCards is an array of all possible hole cards [[Card]] a player can have

    var allPlayerButtons:[NSButton] = []
    var allHandRangeTextFields:[NSTextField] = []
    var allTableCardTextFields:[NSTextField] = []
    var allEquityLabels:[NSTextField] = []
       
    // player select buttons
    @IBOutlet weak var playerButton1: NSButton!
    @IBOutlet weak var playerButton2: NSButton!
    @IBOutlet weak var playerButton3: NSButton!
    @IBOutlet weak var playerButton4: NSButton!
    @IBOutlet weak var playerButton5: NSButton!
    @IBOutlet weak var playerButton6: NSButton!
    
    @IBAction func playerButtonPressed(_ sender: NSButton) {
        selectPlayer(player: sender.tag)
    }
    
    // clear buttons
    @IBAction func clearHandRangeButtonPressed (_ sender: NSButton) {
        curPlayer = sender.tag
        getHandRangeTextField(player: curPlayer).stringValue = String()
        selectPlayer(player: curPlayer)
        clearHoleCardRepGroupButtons()
    }
    @IBAction func clearTableCardsButtonPressed(_ sender: Any) {
        clearTableCards()
    }
    @IBAction func clearEverythingButtonPressed(_ sender: Any) {
        clearEverything()
    }
    
    // hand range text fields
    @IBOutlet weak var handRangeTextField1: NSTextField!
    @IBOutlet weak var handRangeTextField2: NSTextField!
    @IBOutlet weak var handRangeTextField3: NSTextField!
    @IBOutlet weak var handRangeTextField4: NSTextField!
    @IBOutlet weak var handRangeTextField5: NSTextField!
    @IBOutlet weak var handRangeTextField6: NSTextField!
    
    // equity text fields
    @IBOutlet weak var equityLabel1: NSTextField!
    @IBOutlet weak var equityLabel2: NSTextField!
    @IBOutlet weak var equityLabel3: NSTextField!
    @IBOutlet weak var equityLabel4: NSTextField!
    @IBOutlet weak var equityLabel5: NSTextField!
    @IBOutlet weak var equityLabel6: NSTextField!
    
    // percentage of hands text field
    @IBOutlet weak var handRangePctTextField: NSTextField!
    @IBAction func handRangePctTextFieldEdited(_ sender: NSTextField) {
        if (isPctNum(inputText: sender.stringValue)) {
            updateHandRange(handRangeArray: pctToHandRange(pct: Int(sender.stringValue)!))
        }
    }
    
    @IBAction func holeCardRepButtonPressed(_ sender: NSButton) {
        updateHandRange(handRangeArray: handRangeFromButtons())
    }

    @IBAction func groupHoleCardRepButtonPressed(_ sender: NSButton) {
        setHoleCardButtonGroups(groupButton: sender)
        updateHandRange(handRangeArray: handRangeFromButtons())
    }
    
    @IBOutlet weak var tableCardsTextField: NSTextField!
    
    @IBAction func cardButtonPressed(_ sender: NSButton) {
        updateTableCards(button: sender)
    }
    
    
    @IBOutlet weak var evaluateButton: NSButton!
    @IBOutlet weak var simulationStatusLabel: NSTextField!
    @IBAction func evaluateButtonPressed(_ sender: Any) {
        
        // check to make sure there are at least 2 players with possible hands
        guard (countActivePlayers() >= 2) else { return }
        
        toggleSimulationButton()

        if runSimulationFlag {
            runSimulation()
        }

    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        initVars()
                
        selectPlayer(player: curPlayer)
        
    }

    
    func initVars() {
        // initialize variables
               
        // player button array
        allPlayerButtons = [playerButton1, playerButton2, playerButton3, playerButton4, playerButton5, playerButton6]
        
        // hand range text field arrays
        allHandRangeTextFields = [handRangeTextField1, handRangeTextField2, handRangeTextField3, handRangeTextField4, handRangeTextField5, handRangeTextField6]
        allTableCardTextFields = []
        
        // equity label array
        allEquityLabels = [equityLabel1, equityLabel2, equityLabel3, equityLabel4, equityLabel5, equityLabel6]
        
        // allHoleCardReps
        for firstRank in (minRank...maxRank).reversed() {
            for secondRank in (minRank...firstRank).reversed() {
                if (firstRank == secondRank) {
                    allHoleCardReps.append(allRanks[firstRank] + allRanks[firstRank])
                } else {
                    allHoleCardReps.append(allRanks[firstRank] + allRanks[secondRank] + "s")
                    
                    allHoleCardReps.append(allRanks[firstRank] + allRanks[secondRank] + "o")
                }
            }
        }
        
        // allHoleCardRepGroups
        for rank in minRank...maxRank {
            allHoleCardRepGroups.append(allRanks[rank] + "xs")
            allHoleCardRepGroups.append(allRanks[rank] + "xo")
        }
        allHoleCardRepGroups.append(allStr)
        allHoleCardRepGroups.append(pairsStr)
        
        // allCards
        for rank in minRank...maxRank {
            for suit in minSuit...maxSuit {
                allCards.append(allRanks[rank] + allSuits[suit])
            }
        }
    }

    func selectPlayer(player: Int) {
        // select the designated player and load the corresponding hand range
        for button in allPlayerButtons {
            if (button.tag == player) {
                button.state = NSButton.StateValue.on
                curPlayer = player
            } else {
                button.state = NSButton.StateValue.off
            }
        }
        
        // load hand range for the player
        let handRange = handRangeFromTextField()
        updateHandRange(handRangeArray: handRange)
        
        // clear hole card group buttons
        if (handRange.count == 0) {
            // clear hole card rep buttons
            clearHoleCardRepGroupButtons()
        }
        
    }
    
    func toggleSimulationButton() {
        // toggle simulation button and runSimulationFlag
        
        runSimulationFlag = !runSimulationFlag
        
        if runSimulationFlag {
            
            // change button to say stop
            evaluateButton.title = "Stop"
            
        } else {
            // stop simulation
            // change button and label
            evaluateButton.title = "Evaluate"
            
        }
    }
    
    func handRangeFromTextField() -> [String]{
        // get a hand range array from the hand range text field of curPlayer
        let handRangeText = getHandRangeTextField(player: curPlayer).stringValue
        if (handRangeText == String()) {
            return []
        } else {
            return expandHandRange(handRange: handRangeText.components(separatedBy: separator))
        }
    }
        
    
    func getHandRangeTextField(player: Int) -> NSTextField {
        // return the NSTextField with the input tag
        for textField in allHandRangeTextFields {
            if (textField.tag == player) {
                return textField
            }
        }
        return NSTextField()
    }
    
    func handRangeFromButtons() -> [String] {
        // return hand range array from button states
        var handRange:[String] = []
        for view in self.view.subviews as [NSView] {
            if let button = view as? NSButton {
                if allHoleCardReps.contains(button.title) {
                    if (button.state == NSButton.StateValue.on) {
                        handRange.append(button.title)
                    }
                }
            }
        }
        return handRange
    }
    
    func setHoleCardButtonGroups(groupButton: NSButton) {
        // set hole card rep button states based on input button
        
        // get hole card rep buttons to address
        var buttonTitlesArray:[String] = []
        switch groupButton.title {
        case allStr:
            // all hole card reps
            buttonTitlesArray = allHoleCardReps
        case pairsStr:
            // all pairs
            for rank in allRanks {
                buttonTitlesArray.append(rank + rank)
            }
        default:
            // all other groups including Axs, Kxo, etc.
            let firstRank = String(groupButton.title.first!)
            let suitMatch = String(groupButton.title.last!)
            
            for rank in minRank...maxRank {
                buttonTitlesArray.append(firstRank + allRanks[rank] + suitMatch)
            }
            
        }
        
        // set hole card rep buttons
        for view in self.view.subviews as [NSView] {
            if let button = view as? NSButton {
                if buttonTitlesArray.contains(button.title) {
                    button.state = groupButton.state
                }
            }
        }
    }
    
    func clearHoleCardRepButtons() {
        // turn all hole card rep button states to off
        for view in self.view.subviews as [NSView] {
            if let button = view as? NSButton {
                if allHoleCardReps.contains(button.title) {
                    button.state = NSButton.StateValue.off
                }
            }
        }
    }
    
    func clearHoleCardRepGroupButtons() {
        // turn all hole card rep group button states to off
        for view in self.view.subviews as [NSView] {
            if let button = view as? NSButton {
                if allHoleCardRepGroups.contains(button.title) {
                    button.state = NSButton.StateValue.off
                }
            }
        }
    }
    
    func clearTableCards() {
        for view in self.view.subviews as [NSView] {
            if let button = view as? NSButton {
                if allCards.contains(button.title) {
                    button.image = NSImage(named: button.title)
                }
            }
        }
        tableCardsTextField.stringValue = String()
    }
     
    func clearEquityLabels() {
        for label in allEquityLabels {
            label.stringValue = String()
        }
    }
    
    func clearEverything() {
        for textField in allHandRangeTextFields {
            textField.stringValue = String()
        }
        clearHoleCardRepButtons()
        clearHoleCardRepGroupButtons()
        clearTableCards()
        clearEquityLabels()
        curPlayer = 1
        selectPlayer(player: curPlayer)
    }
    
    
    func updateHandRange(handRangeArray: [String]) {
        // updates hand range text fields and buttons with the hand range array
        
        // update buttons
        for view in self.view.subviews as [NSView] {
            if let button = view as? NSButton {
                if allHoleCardReps.contains(button.title) {
                    if handRangeArray.contains(button.title) {
                        button.state = NSButton.StateValue.on
                    } else {
                        button.state = NSButton.StateValue.off
                    }
                }
            }
        }
            
        // update pct
        handRangePctTextField.stringValue = String(handRangeToPct(handRange: handRangeArray))
            
        // update text
        let compressedHandRange = compressHandRange(handRange: handRangeArray)
        getHandRangeTextField(player: curPlayer).stringValue = compressedHandRange.joined(separator: separator)
    }
    
    func isPctNum(inputText: String) -> Bool {
        // return true of the input text is a number from 0 to 100
        let numberInt = Int(inputText)
        if (numberInt != nil) {
            return (numberInt! >= 0 && numberInt! <= 100)
        }
        return false
    }
    
    func pctToHandRange(pct: Int) -> [String] {
        // convert a percentage of hands to a hand range array
        
        // all hole card representations ranked in order
        let holeCardRepRankings = loadHandRankings()
        
        let totalHoleCardCount:Double = 1326 // total number of possible hole cards
        
        // add hole card reps from holeCardRepRankings until the percentage is met
        var holeCardReps:[String] = []
        var holeCardCount:Double = 0
        for holeCardRep in holeCardRepRankings {
            if (holeCardCount / totalHoleCardCount >= Double(pct) / 100.0) {
                // hole card count reached
                break
            }
            // add to the total hole card count
            holeCardReps.append(holeCardRep)
            holeCardCount += countHoleCards(holeCardRep: holeCardRep)
        }
        
        return holeCardReps
    
    }
    
    func handRangeToPct(handRange: [String]) -> Int {
        // get the percentage of hands the input percent represents
        
        // count the number of hole cards in the hand range
        var holeCardCount:Double = 0
        for holeCardRep in handRange {
            holeCardCount += countHoleCards(holeCardRep: holeCardRep)
        }
                
        let totalHoleCardCount:Double = 1326 // total number of possible hole cards
        
        return Int(100 * holeCardCount / totalHoleCardCount)
    }
    
    func countHoleCards(holeCardRep: String) -> Double {
        // return the number of hole cards there are for the input hole card rep
        if (holeCardRep.last == "s") {
            // suited
            return 4
        } else if (holeCardRep.last == "o") {
            // off suit
            return 12
        } else {
            // pair
            return 6
        }
    }
    
    func loadHandRankings() -> [String] {
        // load hand rankings from handRankings.txt
        if let file = Bundle.main.url(forResource: "handRankings", withExtension: "txt") {
            if let content = try? String(contentsOf: file) {
                // load successful
                let handRankingsString = content.components(separatedBy: "\n")
                
                // load content into output array
                var output: [String] = []
                for holeCardRep in handRankingsString {
                    output.append(holeCardRep)
                }
                return output
            }
        }
        
        return []
    }
    
    func expandHandRange(handRange: [String]) -> [String] {
        // takes a hand range that includes hole card reps like "ATs+", "JJ+" and expands them to
        // "ATs", "AJs", "AQs", "AKs", "JJ", "QQ", "KK", "AA"
        
        var expandedHandRange: [String] = []
        for holeCardRep in handRange {
            // one hole card rep
            // check to see if the last character is "+".  If it is, expand the hole card rep
            if (holeCardRep.last == "+") {
                // expand the hand range]]
                let holeCardRepChars:[Character] = Array(holeCardRep) // character array of holeCardRep
                let ranks:[Int] = [ranksDict[holeCardRepChars[0]]!, ranksDict[holeCardRepChars[1]]!] // integer ranks of the two cards
                if (holeCardRepChars[0] == holeCardRepChars[1]) {
                    // pair - add all pairs >= this one
                    for rank in ranks[0]...maxRank {
                        expandedHandRange.append(allRanks[rank] + allRanks[rank])
                    }
                } else {
                    // non-pair - add all hands with the same high card
                    // eg: A8o -> A8o, A9o, ATo, AJo, AQo, AKo
                    for rank in ranks[1]..<ranks[0] {
                        expandedHandRange.append(String(holeCardRepChars[0]) + allRanks[rank] + String(holeCardRepChars[2]))
                    }
                }
            } else {
                // no need to expand this hand range
                expandedHandRange.append(holeCardRep)
            }
        }
        return expandedHandRange
    }
    
    func compressHandRange(handRange: [String]) -> [String] {
        // takes a hand range that includes hole card reps like "AKs", "AQs", "AJs", "AA", KK"
        // and compresses them to "AJs+", "KK+"

        var handRangeRemovable = handRange // copy of handRange to remove elements
        var compressedHandRange: [String] = [] // output array
        
        // pairs
        var lowestConsecutiveHoleCardsRep = String() // the lowest hole card rep of the current type found
        var consecutiveHoleCardsRepCount = 0 // the number of consecutive hole card reps of the current type found
        for rank in (minRank...maxRank).reversed() {
            let holeCardRep = allRanks[rank] + allRanks[rank]
            if handRange.contains(holeCardRep) {
                lowestConsecutiveHoleCardsRep = holeCardRep
                consecutiveHoleCardsRepCount += 1
                handRangeRemovable.remove(at: handRangeRemovable.firstIndex(of: holeCardRep)!) // remove the hole card rep
            } else {
                break
            }
        }
        // add the compressed hand range to compressedHandRange
        if (consecutiveHoleCardsRepCount == 1) {
            compressedHandRange.append(lowestConsecutiveHoleCardsRep)
        } else if (consecutiveHoleCardsRepCount > 1) {
            compressedHandRange.append(lowestConsecutiveHoleCardsRep + "+")
        }
        
        // non-pairs (suited and unsuited)
        for suffix in ["s", "o"] {
            for rank1 in (minRank+1...maxRank).reversed() {
                lowestConsecutiveHoleCardsRep = String() // the lowest hole card rep of the current type found
                consecutiveHoleCardsRepCount = 0 // the number of consecutive hole card reps of the current type found
                for rank2 in (minRank..<rank1).reversed() {
                    let holeCardRep = allRanks[rank1] + allRanks[rank2] + suffix
                    if handRange.contains(holeCardRep) {
                        lowestConsecutiveHoleCardsRep = holeCardRep
                        consecutiveHoleCardsRepCount += 1
                        handRangeRemovable.remove(at: handRangeRemovable.firstIndex(of: holeCardRep)!) // remove the hole card rep
                    } else {
                        break
                    }
                }
                // add the compressed hand range to curComprssedHandRange
                if (consecutiveHoleCardsRepCount == 1) {
                    compressedHandRange.append(lowestConsecutiveHoleCardsRep)
                } else if (consecutiveHoleCardsRepCount > 1) {
                    compressedHandRange.append(lowestConsecutiveHoleCardsRep + "+")
                }
            }
        }
        
        // add remaining hand range reps
        compressedHandRange.append(contentsOf: handRangeRemovable)

        return compressedHandRange
    }
    
    func updateTableCards(button: NSButton) {
        // a card button has been pressed
        // update card state and table card text field
        
        // get table cards as string array
        var tableCardsStringArray: [String] = []
        if (tableCardsTextField.stringValue != String()) {
            tableCardsStringArray = Array(tableCardsTextField.stringValue.components(separatedBy: separator))
        }
        
        if tableCardsStringArray.contains(button.title) {
            // remove the card from tableCardsString
            tableCardsStringArray.remove(at: tableCardsStringArray.firstIndex(of: button.title)!)
            button.image = NSImage(named: button.title)
        } else if (tableCardsStringArray.count < 5) {
            // add the card to tableCardsString
            tableCardsStringArray.append(button.title)
            button.image = NSImage(named: button.title + " gray")
        }
        
        tableCardsTextField.stringValue = tableCardsStringArray.joined(separator: separator)
        
    }
    
    func createPossibleHoleCards(handRanges: [[String]], tableCards: [Card]) -> [[[Card]]] {
        // creates possible hole cards for each player
        // iterates through each combination of hole cards and then matches them to the hand ranges
        
        // create a deck of cards
        var deck:[Card] = []
        for suit in minSuit...maxSuit {
            for rank in minRank...maxRank {
                deck.append(Card(rank:rank, suit:suit))
            }
        }
        
        // iterate through each combination of two cards
        var allHoleCards: [[Card]] = []
        for card1Index in 0..<deck.count-1 {
            for card2Index in card1Index+1..<deck.count {
                // skip table cards
                if allDifferent(cardsArray: tableCards + [deck[card1Index]] + [deck[card2Index]]) {
                    allHoleCards.append([deck[card1Index], deck[card2Index]])
                }
            }
        }
        
        // find hole card combinations that match the input hand ranges
        var allPossibleHoleCards: [[[Card]]] = []
        for curHandRange in handRanges {
            var curPossibleHoleCards: [[Card]] = [] // hole cards for the current player
            for holeCards in allHoleCards {
                let holeCardRep = holeCardToRep(holeCards: holeCards)
                if curHandRange.contains(holeCardRep) {
                    curPossibleHoleCards.append(holeCards)
                }
            }
            allPossibleHoleCards.append(curPossibleHoleCards)
        }
        
        return allPossibleHoleCards
        
    }
    
    func getHandRanges() -> [[String]] {
        // get hand ranges for all players from text fields
        
        var allHandRanges:[[String]] = []
        for textField in allHandRangeTextFields {
            
            let handRangeString = textField.stringValue
            
            if (handRangeString == String()) {
                allHandRanges.append([])
            } else {
                let handRange = handRangeString.components(separatedBy: separator)
                let expandedHandRange = expandHandRange(handRange: handRange)
                allHandRanges.append(expandedHandRange)
            }
        }
        return allHandRanges
    }
    
    func getTableCards() -> [Card] {
        // get table cards from text field
        
        if (tableCardsTextField.stringValue == String()) {
            // no cards
            return []
        }
        let cardsStringArray = Array(tableCardsTextField.stringValue.components(separatedBy: separator))
        
        var tableCards: [Card] = []
        for cardString in cardsStringArray {
            tableCards.append(Card(rank: ranksDict[cardString.first!]!, suit: suitsDict[cardString.last!]!))
        }
        
        return tableCards
        
    }
    
    func holeCardToRep(holeCards: [Card]) -> String {
        // takes a hole card pair and returns holeCardRep string representing the type of hole card
        // eg: "TT" or "A7s" or "K8o"
        
        // get strings of just the rank of each card
        let rank1Str:String = String(holeCards[0].string().first!)
        let rank2Str:String = String(holeCards[1].string().first!)
        
        var holeCardRep: String = String()
        if (holeCards[0].rank == holeCards[1].rank) {
            holeCardRep = rank1Str + rank2Str
        } else {
            if (holeCards[1].rank > holeCards[0].rank) {
                // switch the ranks if the second one is bigger
                holeCardRep = rank2Str + rank1Str
            } else {
                holeCardRep = rank1Str + rank2Str
            }
            if (holeCards[0].suit == holeCards[1].suit) {
                // suited
                holeCardRep += "s"
            } else {
                // unsuited
                holeCardRep += "o"
            }
        }
        return holeCardRep
    }
    
    func countActivePlayers() -> Int {
        // count how many players have hand ranges
        
        var playerCount = 0
        for textField in allHandRangeTextFields {
            if (textField.stringValue != String()) {
                playerCount += 1
            }
        }
        return playerCount        
    }
    
    func runSimulation() {
        // run simulation until the user stops it
                
        // get possible hole cards for all players
        let handRanges = getHandRanges()
        let tableCards = getTableCards()
        let possibleHoleCards = createPossibleHoleCards(handRanges: handRanges, tableCards: tableCards)
        
        // check to make sure all players who have a hand range also have possible hole cards
        for index in 0..<handRanges.count {
            if (handRanges[index] != [] && possibleHoleCards[index].count == 0) {
                // possible hole cards were not found for this hand range
                self.simulationStatusLabel.stringValue = "Hand combination not found"
                self.toggleSimulationButton()
                return
            }
        }
        
        var totalScore:[Double] = Array(repeating: 0, count: numPlayers)
        var equity:[Double] = Array(repeating: 0, count: numPlayers)
                
        numHands = 0
        DispatchQueue.global(qos: .utility).async {

            while runSimulationFlag {

                let score = self.simulateRandomHand(possibleHoleCards: possibleHoleCards, tableCards: tableCards)
                
                if (score == [0]) {
                    // a combination of hole cards and table cards could not be found
                    // if a combination has been found before, try again
                    // if this is the first time, exit the function and alert the user
                    
                    if (numHands == 0) {
                        // first time
                        DispatchQueue.main.async {
                            self.simulationStatusLabel.stringValue = "Hand combination not found"
                            self.toggleSimulationButton()
                        }
                        return
                    }
                    
                }
                numHands += 1
                
                for index in 0..<numPlayers {
                    totalScore[index] += score[index]
                    equity[index] = totalScore[index] / Double(numHands)
                }
                
                DispatchQueue.main.async {
                    for playerIndex in 0..<numPlayers {
                        self.allEquityLabels[playerIndex].stringValue = String(format: "%.2f", equity[playerIndex] * 100) + "%"
                    }
                    
                    // update # hands label
                    self.simulationStatusLabel.stringValue = "Simulating: \(numHands) hands"
                }
                usleep(10)
            }
        }
    }
    
    func simulateRandomHand(possibleHoleCards: [[[Card]]], tableCards: [Card]) -> [Double] {
        // takes an array of possible hole cards for each player and array of table cards
        // randomly picks a hole card for each player, deals remaining table cards
        // returns an array representing the winner: 1 point for win, 0 points for lose, the 1 win point is shared among tying players
        // it's assumed that possibleHoleCards does not contain tableCards
                       
        var holeCards:[[Card]] = Array(repeating: [], count: numPlayers)
        var filledTableCards: [Card] = [] // all 5 table cards, filled with random cards if less than 5 are input
        var cardSelectCount = 0 // number of tries to select cards, used to check if a combination cannot be found
        
        while true {
            // randomly choose hole cards for each player
            for playerIndex in 0..<numPlayers {
                // pick a random hole card, only if the player has possible hole cards
                if (possibleHoleCards[playerIndex].count > 0) {
                    holeCards[playerIndex] = possibleHoleCards[playerIndex].randomElement()!
                }
            }
            
            // choose remaining table cards
            filledTableCards = tableCards
            while (filledTableCards.count < 5) {
                filledTableCards.append(Card(rank: Int.random(in: minRank...maxRank), suit: Int.random(in: minSuit...maxSuit)))
            }
            
            // make sure all used cards are unique
            var selectedCards:[Card] = []
            for holeCard in holeCards {
                if (holeCard.count == 2) {
                    selectedCards.append(holeCard[0])
                    selectedCards.append(holeCard[1])
                }
            }
            for card in filledTableCards {
                selectedCards.append(card)
            }
            if allDifferent(cardsArray: selectedCards) {
                break
            } else {
                cardSelectCount += 1
                if (cardSelectCount == 1000) {
                    print("A combination of cards to play the hand could not be found.")
                    return [0]
                }
            }
        }
        // create hands for each player
        var playerHands:[[Card]] = Array(repeating: [], count: numPlayers)
        for playerIndex in 0..<numPlayers {
            if (holeCards[playerIndex].count > 0) {
                playerHands[playerIndex] = holeCards[playerIndex] + filledTableCards
            }
        }
        
        return compareHands(handsArray: playerHands)
    
    }
    
    
}




