//
//  CardSelectViewController.swift
//  PokerLab
//
//  Created by Daniel Davies on 7/2/20.
//  Copyright © 2020 Daniel Davies. All rights reserved.
//

import Cocoa

class CardSelectViewController: NSViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do view setup here.
    }
    
}
